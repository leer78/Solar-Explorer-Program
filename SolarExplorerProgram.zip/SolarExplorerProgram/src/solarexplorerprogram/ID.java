
package solarexplorerprogram;
public enum ID { // ids just help to identify the object a lot clearer
    Player(), 
    Sun(),
    Mercury(),
    Venus(),
    Earth(),
    Moon(),
    Mars(),
    AsteroidBelt(),
    Jupiter(),
    Saturn(),
    Uranus(),
    Neptune(),
    KuiperBelt(),
    Pluto(),
    oortCloudStart(),
    oortCloudEnd(),
    Star();
}
