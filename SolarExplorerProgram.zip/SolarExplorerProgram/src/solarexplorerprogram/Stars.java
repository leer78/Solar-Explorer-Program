package solarexplorerprogram;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.util.Random;

public class Stars extends Object {

    Random rand = new Random();
    Handler handler;

    public Stars(int xPos, int yPos, ID id, int travelSpeed, Handler handler, boolean isViewed) {// star constructor
        super(xPos, yPos, id, travelSpeed, isViewed);
        this.handler = handler;
        this.yPos = rand.nextInt(560);
        this.isViewed = isViewed;

    }

    @Override
    public void tick() {
        xPos += -velX / 20; // stars move slowly in the background
        yPos += velY / 20;
        resetPos();
    }

    public void resetPos() {
        //method allows for stars to infinately generate as you pass them
        if (xPos < 0) {
            yPos = rand.nextInt(560);
            xPos = 1200;
        }
        else if (xPos > 1200) {
             yPos = rand.nextInt(560);
             xPos = 0;
        }
    }

    @Override
    public void render(Graphics g, int objectNum) {
        g.setColor(Color.WHITE);
        if (handler.object.get(0).getVelX() < 100 && handler.object.get(0).getVelX() > -100) {
            int twinkle = rand.nextInt(2); // varies the size of stars, give them a twinkle look
            g.fillRect(xPos, yPos, 2 + twinkle, 2 + twinkle);
        } else {
            int modifier =  handler.object.get(0).getVelX(); // based on speed, star trails form 
            if (modifier * -1 > 0) {
                modifier = modifier * -1;
            }
            int starTrail = modifier/5;
            
            g.drawLine(xPos, yPos, xPos - starTrail, yPos);

        }

    }

}
