package solarexplorerprogram;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Random;
import java.util.Set;

public class Window implements ActionListener {

    Handler handler;
    int view = 1;

    static void add(JPanel textPanel) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Window(int width, int height, String title, SolarExplorerProgram SolarExplorerProgram, int x, int y, Handler handler) { // window constructor
        this.handler = handler;
        JFrame frame = new JFrame(title);
        frame.setLocation(x, y);
        frame.setPreferredSize(new Dimension(width, height));
        frame.setMaximumSize(new Dimension(width, height));
        frame.setMinimumSize(new Dimension(width, height));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        if (title.equals("Control Panel")) { // adds button for inspecting
            frame.setLayout(new GridLayout(1, 1));

            JButton locations[] = new JButton[16];
            locations[0] = new JButton("Inspect");
            locations[0].addActionListener(this);
            frame.add(locations[0]);


        } else {
            frame.add(SolarExplorerProgram);
        }
        frame.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) { // actionlistener for the button
        String buttonPressed = e.getActionCommand();
        int xPosObject = 0;
        switch (buttonPressed) {
            case ("Inspect"):
                inspectPlanet();
        }
        //changeXPosAll(xPosObject);
        System.out.println(buttonPressed);
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    public void inspectPlanet() {

        if (view == 1) { // if inspect is pressed and object is within 1000 range, updates the object state to viewed
            int shipx = handler.object.get(0).getxPos();
            for (int i = 1; i < 16; i++) {
                if (((shipx - handler.object.get(i).getxPos() < 1000 && shipx - handler.object.get(i).getxPos() > 0) || (handler.object.get(i).getxPos() - shipx < 1000 && handler.object.get(i).getxPos() - shipx > 0)) && handler.object.get(i).getId() != ID.Moon) {
                    handler.object.get(i).setIsViewed(true);
                }
            }
            view = 0;
        }
        else{
            for (int i = 1; i < 16; i++) {
                handler.object.get(i).setIsViewed(false);
                
            }
            view = 1;
        }

    }
}
