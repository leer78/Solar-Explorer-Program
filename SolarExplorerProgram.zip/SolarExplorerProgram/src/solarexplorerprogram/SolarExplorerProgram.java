package solarexplorerprogram;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.lang.Math;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.Scanner;

public class SolarExplorerProgram extends Canvas implements Runnable {

    private static final long serialVersionUID = 1L;
    private boolean isRunning = false;
    private Handler handler;
    private Thread thread;
    public static Object objects[] = new Object[13];
    public static int travelSpeed = 1;
    public long start, finish, elapsed, tempEnd;
    public BufferedImage cockpit = null;
    Font font;
    public BufferedImage arrowleft = null;
    public BufferedImage arrowright = null;
    public BufferedImage descBox = null;
    public BufferedImage titleScreen = null;
    public BufferedImage title = null;
    public BufferedImage instr1 = null;
    public BufferedImage instr2 = null;

    public SolarExplorerProgram() {

        Random rand = new Random(); //Allows for the usage of random numbers

        BufferedImageLoader loader = new BufferedImageLoader(); // Buffered Image Loader instance
        handler = new Handler(); // New instance of handler class which basically is what all actions are processed through like methods
        new Window(1200, 200, "Control Panel", this, 0, 570, handler); // creates windows
        new Window(1200, 560, "Solar Explorer", this, 0, 0, handler);

        this.addKeyListener(new KeyInput(handler)); // adds key listener
        //creates objects and adds them to an array list in handler class
        handler.addObject(new SpaceShip(600, 230, ID.Player, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(0, 230, ID.Sun, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(17149, 230, ID.Mercury, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(31625, 230, ID.Venus, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(43177, 230, ID.Earth, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(43282, 230, ID.Moon, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(66081, 230, ID.Mars, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(94736, 230, ID.AsteroidBelt, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(224576, 230, ID.Jupiter, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(413003, 230, ID.Saturn, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(828636, 230, ID.Uranus, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(1295336, 230, ID.Neptune, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(1296684, 230, ID.KuiperBelt, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(1700644, 230, ID.Pluto, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(86355785, 230, ID.oortCloudStart, travelSpeed, handler, false));
        handler.addObject(new SpaceObject(431778929, 230, ID.oortCloudEnd, travelSpeed, handler, false));

        //generates random initial positions for the stars and creates the objects
        for (int i = 0; i < 30; i++) {
            int xStar = rand.nextInt(1200);
            int yStar = rand.nextInt(560);
            handler.addObject(new Stars(xStar, yStar, ID.Star, travelSpeed, handler, false));
        }
        start(); // starts running all the non static things
    }

    private void start() {

        isRunning = true;
        thread = new Thread(this);
        thread.start();

    }

    private void stop() {
        isRunning = false;
        try {
            thread.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        //This method is one I copied from a video, essentially runs a certain number of times
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 86.2959; // basically frames per second
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int frames = 0;
        while (isRunning) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while (delta >= 1) {
                tick();
                delta--;
            }

            render(); // calls render method
            frames++; 

            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                frames = 0;

            }

        }
        stop();
    }

    public void tick() {
        //Every time tick is called, the handler goes through the list of objects and runs through important methods like updating graphics or locations
        handler.tick();
    }

    public void render() {
        //This method is called every run() loop and redraws everything on the screen
        int titleMotion = 0;
        BufferStrategy bs = this.getBufferStrategy(); // Not sure what this does, copied a youtube video
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }

        Graphics g = bs.getDrawGraphics(); // Allows the use of graphics
        ///////////// Everything within this comment section is what will be displayed

        if (handler.object.get(0).getState() == 1) { //State 1 is the homescreen
            try { // Initializes images
                titleScreen = ImageIO.read(new File("Homescreen.png"));
                title = ImageIO.read(new File("title.png"));

            } catch (Exception e) {
            }
            g.drawImage(titleScreen, 0, -50, null);
            g.drawImage(title, 300, 100, null);
        }
        if (handler.object.get(0).getState() == 2 || handler.object.get(0).getState() == 4) { // sate 2 is instruction screen 1, 4 is the second instruction screen
            try {
                instr1 = ImageIO.read(new File("instr1.png"));
                instr2 = ImageIO.read(new File("instr2.png"));
            } catch (Exception e) {
                System.out.println("error");
            }
            if (handler.object.get(0).getState() == 2) { // displays the respective instruction screen
                g.drawImage(instr1, 0, 0, null);
            }
            if (handler.object.get(0).getState() == 4) {
                g.drawImage(instr2, 0, 0, null);
            }
            
        }
        if (handler.object.get(0).getState() == 3) { // This is the actual game graphics
            g.setFont(new Font("digital-7", Font.BOLD, 30)); // Creates new font that I imported
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, 1200, 560);
            g.setColor(Color.YELLOW);
            String km = Long.toString(handler.object.get(0).getKm() * 3474); // displays distance from the sun in km
            g.drawString(km + " [KM]", 80, 80);

            ////////////// 
            // everything below this renders the objects like planets and draws them
            handler.render(g);
            handler.object.get(0).render(g, 0);

            displayHUD(); //calls method for the visuals on screen
        }
        g.dispose(); // This actually puts everything on the screen
        bs.show();

    }

    public void displayHUD() {
        //This method just displays things on screen like speed etc
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();
        try {
            cockpit = ImageIO.read(new File("cockpit.png"));
            arrowright = ImageIO.read(new File("arrow right.png"));
            arrowleft = ImageIO.read(new File("arrow left.png"));
            descBox = ImageIO.read(new File("hud.png"));
        } catch (Exception e) {
        }
        g.drawImage(cockpit, 0, 0, null); // draws cockpit image

        g.setFont(new Font("digital-7", Font.BOLD, 30));
        int printX = displaySpeed(handler.object.get(0).getVelX() * 299792); // displays speed at in terms of the speed of light
        g.setColor(Color.YELLOW);
        String speed = Integer.toString(handler.object.get(0).getVelX() * 299792);
        g.drawString(speed + " [km/s]", printX, 500);

        DecimalFormat df = new DecimalFormat("0.00");
        for (int i = 1; i < 16; i++) { // This whole thing calculates how close you are to objects on your left and right
            // Converts them to long variables and displays in astronomical units 150 million km
            if (handler.object.get(0).getxPos() > handler.object.get(i - 1).getxPos() && handler.object.get(0).getxPos() < handler.object.get(i).getxPos()) {
                // ^ this just checks when ur position is in between 2 objects
                Long cl = new Long(((handler.object.get(0).getxPos() - handler.object.get(i - 1).getxPos())));
                cl = cl * 3474;
                double cld = cl / 150000000.;

                Long cr = new Long(((handler.object.get(i).getxPos() - handler.object.get(0).getxPos())));
                cr = cr * 3474;
                double crd = cr / 150000000.;

                df.setRoundingMode(RoundingMode.UP);

                String closeLeft = df.format(cld);
                String closeRight = df.format(crd);

                int crdPrintSpot = 1075;
                //int printDisplacement = displaySpeed((handler.object.get(i).getxPos() - handler.object.get(0).getxPos()) * 3474);
                if (crd > 1000) {
                    crdPrintSpot = 1050;
                }

                g.drawString(closeLeft + "[AU]", 10, 230); //prints distance on left
                g.drawString(closeRight + "[AU]", crdPrintSpot, 230); // prints distance on right
                g.setFont(new Font("thin", Font.PLAIN, 20));
                String obj = whichPlanet(i - 1);
                g.drawString(obj, 10, 260);
                obj = whichPlanet(i);
                if (obj.equals("Oort cloud start") || obj.equals("Oort cloud end")) { // this just displays things with longer names in the correct place
                    g.drawString(obj, 1050, 260);
                } else if (obj.equals("Asteroid Belt")) {
                    g.drawString(obj, 1075, 260);
                } else {
                    g.drawString(obj, 1100, 260);
                }
                g.drawImage(arrowleft, 10, 270, null);
                g.drawImage(arrowright, 1125, 270, null);
                i = 16; // ends loop

            }
        }

        File objectsInfo = new File("objectInfo.txt"); // opens the text file with information
        
        String planetName = "";
        String desc1 = "";
        String desc2 = "";
        String diameter = "";
        String mass = "";
        String orbit = "";
        String surfTemp = "";
        String moons = "";
        int counter = 1;

        for (int i = 1; i < 16; i++) { // loops to display info when you are near a planet
            if (handler.object.get(i).isIsViewed()) { // when close to an object, allows inspect option
                String planet = whichPlanet(i);

                try {
                    FileReader fr = new FileReader("objectInfo.txt"); // creates file reader
                    Scanner c = new Scanner(fr);
                    while (c.hasNextLine()) { //Checks each line on the text file and searches for the planet you are closest to
                        String line = c.nextLine();
                        if (line.equals(planet)) { // if close, reads the next line and saves the info into variables
                            planetName = line;
                            desc1 = c.nextLine();
                            desc2 = c.nextLine();
                            diameter = c.nextLine();
                            mass = c.nextLine();
                            orbit = c.nextLine();
                            surfTemp = c.nextLine();
                            moons = c.nextLine();
                            counter = 0;
                        }

                    }
                    c.close();

                } catch (Exception e) {
                    System.out.println("error");
                }

                //displays all the object info when inspected
                g.setFont(new Font("thin", Font.PLAIN, 10));
                g.drawString("Object name: " + planetName, 760, 125);
                g.drawString("Diameter : " + diameter, 760, 140);
                g.drawString("Mass : " + mass, 760, 155);
                g.drawString("Orbit time: " + orbit, 760, 170);
                g.drawString("Surface Temperature: " + surfTemp, 760, 185);
                g.drawString("Number of moons : " + moons, 760, 195);
                g.setFont(new Font("thin", Font.PLAIN, 9));
                g.drawString(desc1, 760, 210);
                g.drawString(desc2, 760, 225);
                g.drawImage(descBox, 700, 30, null);

            }

        }

    }

    public String whichPlanet(int num) {
        //used to return a planet name
        String planet = "";
        switch (num) {
            case (1):
                planet = "Sun";
                break;
            case (2):
                planet = "Mercury";
                break;
            case (3):
                planet = "Venus";
                break;
            case (4):
                planet = "Earth";
                break;
            case (5):
                planet = "Moon";
                break;
            case (6):
                planet = "Mars";
                break;
            case 7:
                planet = "Asteroid Belt";
                break;
            case (8):
                planet = "Jupiter";
                break;
            case (9):
                planet = "Saturn";
                break;
            case (10):
                planet = "Uranus";
                break;
            case (11):
                planet = "Neptune";
                break;
            case (12):
                planet = "Kuiper Belt";
                break;
            case (13):
                planet = "Pluto";
                break;
            case (14):
                planet = "Oort cloud start";
                break;
            case (15):
                planet = "Oort cloud end";
                break;
        }
        return planet;

    }

    public static void main(String[] args) {
        new SolarExplorerProgram();
        /*
         String fonts[]
         = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();

         for (int i = 0; i < fonts.length; i++) {
         System.out.println(fonts[i]);
         }
         */

        try {
            //registers imported fonts
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("digital-7.ttf")));
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("thin.ttf")));
        } catch (Exception e) {

        }

    }

    public int displaySpeed(int speed2) {
        //Displays speed, changes display position based on the number of numbers in it
        int x = 0;
        if (speed2 * -1 >= 0) {
            speed2 = speed2 * -1;
        }
        if (speed2 == 0) {
            x = 550;
        } else if (speed2 > 0 && speed2 < 1000000) {
            x = 500;
        } else if (speed2 > 1000000 && speed2 < 10000000) {
            x = 495;
        } else if (speed2 > 10000000 && speed2 < 100000000) {
            x = 490;
        } else if (speed2 > 100000000 && speed2 < 1000000000) {
            x = 485;
        } else {
            x = 450;
        }
        return x;

    }

}
