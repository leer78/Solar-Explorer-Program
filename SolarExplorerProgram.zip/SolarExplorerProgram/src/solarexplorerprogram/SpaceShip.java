package solarexplorerprogram;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class SpaceShip extends Object { // spaceship constructor

    Handler handler;
    public int acceleration = 0;
    public int movement = 0;
    public int defaultPos = 600;
    public int newPos = 600;

    public BufferedImage shipaccellright = null;
    public BufferedImage shipaccellleft = null;
    public BufferedImage shipdefaultright = null;
    public BufferedImage shipdefaultleft = null;


    public SpaceShip(int xPos, int yPos, ID id, int travelSpeed, Handler handler, boolean isViewed) {
        super(xPos, yPos, id, travelSpeed, isViewed);
        this.handler = handler;
        this.isViewed = isViewed;


    }


    @Override
    public void tick() {
        //This is called everytime the run() in main class runs, used to update visuals and location
        yPos += velY;

        //These are used when the movement buttons are pressed
        //Includes the motions for when a player holds a key to accelerate
        if (handler.isUp()) {
            velY = -travelSpeed * 2;
        } else if (!handler.isDown()) {
            velY = 0;
        }

        if (handler.isDown()) {
            velY = travelSpeed * 2;
        } else if (!handler.isUp()) {
            velY = 0;
        }

        if (handler.isRight()) {
            velX += travelSpeed;
            acceleration = 1;
            //km = km  + travelSpeed;
        } else if (!handler.isLeft()) {
            //velX = 0;
            acceleration = 0;

        }

        if (handler.isLeft()) {
            velX += -travelSpeed;
            //km = km -travelSpeed;
            acceleration = -1;
        } else if (!handler.isRight()) {
            //velX = 0;
            acceleration = 0;
        }
        for (int i = 0; i < handler.object.size(); i++) {
            handler.object.get(i).setVelX(velX);
        }
        
        km = km + velX; // updates position from the sun
    }

    @Override
    public void render(Graphics g, int objectNum) {
        //Displays the visuals and psition of the ship itself. Changes the display of the ship based on direction and motion
        try {
                
            shipaccellright = ImageIO.read(new File("shipaccellright.png"));
            shipaccellleft = ImageIO.read(new File("shipaccellleft.png"));
            shipdefaultright = ImageIO.read(new File("shipdefaultright.png"));
            shipdefaultleft = ImageIO.read(new File("shipdefaultleft.png"));
            
        } catch (IOException e) {
            //System.out.println("hi");
        }
        //g.drawImage(spaceship, 100, 100, null);
        //Not accelerating, default spot

        if (acceleration == 0) { //  when not accelerating
            movement = 0;
            if (newPos < defaultPos) {
                newPos += 2;
                g.drawImage(shipaccellleft, newPos - 50, yPos, null);
                //g.setColor(Color.PINK);
                //g.fillRect(newPos, yPos, 30, 30);

            } else if (newPos > defaultPos) {
                g.setColor(Color.PINK);
                newPos -= 2;
                g.drawImage(shipaccellright, newPos, yPos, null);
                //g.fillRect(newPos, yPos, 30, 30);
            } else {
                g.setColor(Color.BLUE);
                if (velX >= 0) {
                    g.drawImage(shipaccellright, newPos, yPos, null);
                }
                else{
                    g.drawImage(shipaccellleft, newPos - 50, yPos, null);
                }
                
                //g.fillRect(newPos, yPos, 30, 30);
                //g.drawImage(spaceship,newPos,yPos,null);
            }

        }

        if (acceleration == 1) { // when accelerating in the right direction
            if (movement <= 200) {
                movement += 2;
                g.setColor(Color.RED);
                newPos = defaultPos + movement;
                g.drawImage(shipaccellright, newPos, yPos, null);
                //g.fillRect(newPos, yPos, 30, 30);

            } else {
                g.setColor(Color.PINK);
                newPos = defaultPos + 200;
                g.drawImage(shipdefaultright, newPos, yPos, null);
                //g.fillRect(newPos, yPos, 30, 30);
            }

        }
        if (acceleration == -1) { // when accelerating in left direction
            if (movement <= 200) {
                movement += 2;
                g.setColor(Color.RED);
                newPos = defaultPos - movement;
                g.drawImage(shipaccellleft, newPos - 50, yPos, null);
                //g.fillRect(newPos, yPos, 30, 30);
            } else {
                g.setColor(Color.PINK);
                newPos = defaultPos - 200;
                g.drawImage(shipdefaultleft, newPos - 50, yPos, null);
                //g.fillRect(newPos, yPos, 30, 30);
            }

        }

    }

}
