package solarexplorerprogram;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class KeyInput extends KeyAdapter {

    Handler handler;

    public KeyInput(Handler handler) { // key input constructor
        this.handler = handler; 
    }

    @Override
    //Having key pressed and key released makes movement much smoother without lag
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        
        if (handler.object.get(0).getState() == 1) { //changes to homescreen
            if (key == KeyEvent.VK_1) { // changes state to instructions
                handler.object.get(0).setState(2);
                System.out.println("instruction state ");
            }
            if (key == KeyEvent.VK_2) { // changes state to game
                handler.object.get(0).setState(3);
                System.out.println("game state");
            }
        }
        if (handler.object.get(0).getState() == 2 || handler.object.get(0).getState() == 4) { //changes to instructions and which instruction page
            if (key == KeyEvent.VK_1) {
                handler.object.get(0).setState(2);
                System.out.println("instr1");
            }
            if (key == KeyEvent.VK_2) {
                handler.object.get(0).setState(4);
                System.out.println("instr2");
            }
            if (key == KeyEvent.VK_ESCAPE) {
                handler.object.get(0).setState(1);
                System.out.println("exit");
            }
        }
        if (handler.object.get(0).getState() == 3) { // changes to game, allows for key movement

            for (int i = 0; i < handler.object.size(); i++) {
                Object tempObject = handler.object.get(i);

                if (tempObject.getId() == ID.Player) {
                    if (key == KeyEvent.VK_W) {
                        handler.setUp(true);
                    }
                    if (key == KeyEvent.VK_S) {
                        handler.setDown(true);
                    }
                    if (key == KeyEvent.VK_A) {
                        handler.setLeft(true);
                    }
                    if (key == KeyEvent.VK_D) {
                        handler.setRight(true);
                    }
                    if (key == KeyEvent.VK_D) {
                        handler.setRight(true);
                    }
                    //Changes travel speed of every object

                    if (key == KeyEvent.VK_R) { // changes speed to 1
                        for (int j = 0; j < handler.object.size(); j++) {
                            if (handler.object.get(0).getVelX() >= 0) {
                                handler.object.get(j).setVelX(1);
                            } else {
                                handler.object.get(j).setVelX(-1);
                            }

                        }
                    }
                    if (key == KeyEvent.VK_E) { // changes speed to 0 and stops
                        for (int j = 0; j < handler.object.size(); j++) {
                            handler.object.get(j).setVelX(0);
                        }
                    }

                    
                }
            }
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        
        if (handler.object.get(0).getState() == 3) {

            for (int i = 0; i < handler.object.size(); i++) {
                Object tempObject = handler.object.get(i);

                if (tempObject.getId() == ID.Player) {
                    if (key == KeyEvent.VK_W) {
                        handler.setUp(false);
                    }
                    if (key == KeyEvent.VK_S) {
                        handler.setDown(false);
                    }
                    if (key == KeyEvent.VK_A) {
                        handler.setLeft(false);
                    }
                    if (key == KeyEvent.VK_D) {
                        handler.setRight(false);
                    }

                }

            }
        }

    }
}
