
package solarexplorerprogram;

import java.awt.Color;
import java.awt.Graphics;

public class Object {
    public int xPos;
    public int yPos;
    public long km;
    public int velX;
    public int velY;
    public ID id;
    public int travelSpeed;
    public boolean isViewed;
    public int state;
    public Object(int xPos, int yPos, ID id, int travelSpeed, boolean isViewed){ // object constructor
        this.xPos = xPos;
        this.yPos = yPos;
        this.travelSpeed = travelSpeed;
        this.id = id;
        this.isViewed = false;
        this.state = 1;
    }

    public int getState() { // state is for checking the game state (eg. homescreen etc)
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }



    public boolean isIsViewed() { // viewed is to see if its within inspect rance
        return isViewed;
    }

    public void setIsViewed(boolean isViewed) {
        this.isViewed = isViewed;
    }

    public int getTravelSpeed() { // gets travel speed
        return travelSpeed; 
    }

    public void setTravelSpeed(int travelSpeed) {
        this.travelSpeed = travelSpeed;
    }

    
    public int getVelX() { // gets velocity in x direction
        return velX;
    }

    public void setVelX(int velX) {
        this.velX = velX;
    }

    public int getVelY() { // gets velocity in y direction
        return velY;
    }

    public void setVelY(int velY) {
        this.velY = velY;
    }

    public int getxPos() { // gets x pos
        return xPos;
    }

    public void setxPos(int xPos) {
        this.xPos = xPos;
    }

    public int getyPos() { // gets y pos
        return yPos;
    }

    public void setyPos(int yPos) {
        this.yPos = yPos;
    }

    public long getKm() { // gets distance from the sun
        return km;
    }

    public void setKm(long km) {
        this.km = km;
    }

    public ID getId() { // gets the id of the object
        return id;
    }

    public void setId(ID id) {
        this.id = id;
    }
    
    
    public void tick(){ // handler acceses these methods
        
    }
    public void render(Graphics g, int objectNum){

    }
    
    
}
