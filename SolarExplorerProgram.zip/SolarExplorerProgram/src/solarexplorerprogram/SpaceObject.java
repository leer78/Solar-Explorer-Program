package solarexplorerprogram;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class SpaceObject extends Object {

    Handler handler;
    public BufferedImage sun = null;
    public BufferedImage jupiter = null;
    public BufferedImage saturn = null;
    public BufferedImage uranus = null;
    public BufferedImage neptune = null;
    public SpaceObject(int xPos, int yPos, ID id, int travelSpeed, Handler handler, boolean isViewed) { // all space objects costructor
        super(xPos, yPos, id, travelSpeed, isViewed);
        this.handler = handler;
        try {
            sun = ImageIO.read(new File("sun.png"));
            jupiter = ImageIO.read(new File("jupiter.png"));
            saturn = ImageIO.read(new File("saturn.png"));
            uranus = ImageIO.read(new File("uranus.png"));
            neptune = ImageIO.read(new File("neptune.png"));
        } catch (Exception e) {
        }

    }

    @Override
    public void tick() { // updates the position based on the movement of the spaceship
        xPos += -velX;
        yPos += velY;

    }

    @Override
    public void render(Graphics g, int objectNum) {
        //Displays the objects and their names
        Color lightBlue = new Color(173, 216, 230);
        Color silver = new Color(192, 192, 192);
        g.setColor(Color.WHITE);
        g.setFont(new Font("thin", Font.PLAIN, 40));
        switch (objectNum) {
            //Sun
            case (1):
                yPos = 100;
                g.drawLine(xPos + 250, yPos + 50, xPos + 250, 100);
                g.drawString("SUN", xPos + 250, 100);
                g.drawImage(sun, xPos, yPos, null);

                break;
            //Mercury
            case (2):
                g.setColor(Color.GRAY);
                g.drawLine(xPos, yPos - 20, xPos, yPos - 120);
                g.drawString("MERCURY", xPos, 100);
                g.setColor(Color.WHITE);
                g.fillRect(xPos, yPos, 1, 1);
                break;
            //Venus
            case (3):
                g.setColor(Color.WHITE);
                g.drawLine(xPos + 2, yPos - 20, xPos + 2, yPos - 120);
                g.setColor(Color.CYAN);
                g.drawString("VENUS", xPos + 2, 100);
                g.fillOval(xPos, yPos, 4, 4);
                break;
            //Earth
            case (4):
                g.setColor(Color.WHITE);
                g.drawLine(xPos + 2, yPos - 20, xPos + 2, yPos - 120);
                g.setColor(Color.BLUE);
                g.drawString("EARTH", xPos + 2, 100);
                g.fillOval(xPos, yPos, 4, 4);
                break;
            //Moon
            case (5):
                g.setColor(Color.WHITE);
                g.drawLine(xPos, yPos + 20, xPos, yPos + 120);
                g.setColor(Color.GRAY);
                g.drawString("MOON", xPos, 400);
                g.fillRect(xPos, yPos, 1, 1);
                break;
            //Mars
            case (6):
                g.setColor(Color.WHITE);
                g.drawLine(xPos + 2, yPos + 20, xPos + 2, yPos + 120);
                g.setColor(Color.RED);
                g.drawString("MARS", xPos + 2, 400);
                g.fillOval(xPos, yPos, 2, 2);
                break;
            //Asteroid belt
            case (7):
                g.setColor(Color.GRAY);
                g.drawLine(xPos, 0, xPos, 560);
                g.drawString("ASTEROID BELT START", xPos - 230, 100);
                break;
            //Jupiter
            case (8):
                g.setColor(Color.ORANGE);
                g.drawLine(xPos + 25, yPos - 18, xPos + 25, yPos - 120);
                g.drawString("JUPITER", xPos + 25, 100);
                g.drawImage(jupiter, xPos, yPos, null);

                break;
            //Saturn
            case (9):
                g.setColor(Color.YELLOW);
                g.drawLine(xPos + 40, yPos - 18, xPos + 40, yPos - 120);
                g.drawString("SATURN", xPos + 40, 100);
                g.drawImage(saturn, xPos, yPos, null);
                break;
            //Uranus
            case (10):
                g.setColor(lightBlue);
                g.drawLine(xPos + 8, yPos + 20, xPos + 8, yPos + 120);
                g.setColor(lightBlue);
                g.drawString("URANUS", xPos + 8, 400);
                g.drawImage(uranus, xPos, yPos, null);
                break;
            //Neptune
            case (11):
                g.setColor(Color.BLUE);
                g.drawLine(xPos + 8, yPos + 20, xPos + 8, yPos + 120);
                g.setColor(Color.BLUE);
                g.drawString("NEPTUNE", xPos + 8, 400);
                g.drawImage(neptune, xPos, yPos, null);
                break;
            // Kuiperbelt
            case (12):
                g.setColor(Color.GRAY);
                g.drawLine(xPos, 0, xPos, 560);
                g.drawString("KUIPER BELT START", xPos - 200, 100);
                break;
            // Pluto
            case (13):
                g.setColor(silver);
                g.drawLine(xPos, yPos + 20, xPos, yPos + 120);
                g.setColor(silver);
                g.drawString("PLUTO", xPos, 400);
                g.fillRect(xPos, yPos, 1, 1);
                break;
            // oort cloud start
            case (14):
                g.setColor(Color.GRAY);
                g.drawLine(xPos, 0, xPos, 560);
                g.drawString("OORT CLOUD START", xPos - 200, 100);
                break;
            // oort cloud end (end of suns gravity)
            case (15):
                g.setColor(Color.GRAY);
                g.drawLine(xPos, 0, xPos, 560);
                g.drawString("OORT CLOUD END/EDGE OF SOLAR SYSTEM", xPos - 400, 100);
                break;

        }
    }

}
