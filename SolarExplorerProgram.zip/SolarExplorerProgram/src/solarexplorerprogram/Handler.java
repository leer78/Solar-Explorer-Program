package solarexplorerprogram;

import java.awt.Graphics;
import java.util.LinkedList;

public class Handler { // I copied this from a youtube video, basically allows for accessing objects and controlling them with ease

    LinkedList<Object> object = new LinkedList<Object>(); // creates array list for objects
    
    boolean up = false;
    boolean down = false;
    boolean left = false;
    boolean right = false;

    public void tick() {
        for (int i = 0; i < object.size(); i++) {
            Object tempObject = object.get(i);
            tempObject.tick();
        }
    }

    public void render(Graphics g) { // this loops and goes through the object list
        //Finds the object id and sends it to the object render method
        int objectNum = 1;
        for (int i = 0; i < object.size(); i++) {
            Object tempObject = object.get(i);
            if (tempObject.getId() == ID.Sun) {
                objectNum = 1;
            }   
            if (tempObject.getId() == ID.Mercury) {
                objectNum = 2;
            }
            if (tempObject.getId() == ID.Venus) {
                objectNum = 3;
            }
            if (tempObject.getId() == ID.Earth) {
                objectNum = 4;
            }
            if (tempObject.getId() == ID.Moon) {
                objectNum = 5;
            }
            if (tempObject.getId() == ID.Mars) {
                objectNum = 6;
            }
            if (tempObject.getId() == ID.AsteroidBelt) {
                objectNum = 7;
            }
            if (tempObject.getId() == ID.Jupiter) {
                objectNum = 8;
            }
            if (tempObject.getId() == ID.Saturn) {
                objectNum = 9;
            }
            if (tempObject.getId() == ID.Uranus) {
                objectNum = 10;
            }
            if (tempObject.getId() == ID.Neptune) {
                objectNum = 11;
            }
            if (tempObject.getId() == ID.KuiperBelt) {
                objectNum = 12;
            }
            if (tempObject.getId() == ID.Pluto) {
                objectNum = 13;
            }
            if (tempObject.getId() == ID.oortCloudStart) {
                objectNum = 14;
            }
            if (tempObject.getId() == ID.oortCloudEnd) {
                objectNum = 15;
            }
            if (tempObject.getId() == ID.Star) {
                objectNum = 16;
            }
            
                    
            tempObject.render(g,objectNum); // renders the image in spaceobject class
        }
    }
    

    public void addObject(Object tempObject) {
        object.add(tempObject);
    }

    public void removeObject(Object tempObject) {
        object.remove(tempObject);
    }

    public boolean isUp() {
        return up;
    }

    public void setUp(boolean up) {
        this.up = up;
    }

    public boolean isDown() {
        return down;
    }

    public void setDown(boolean down) {
        this.down = down;
    }

    public boolean isLeft() {
        return left;
    }

    public void setLeft(boolean left) {
        this.left = left;
    }

    public boolean isRight() {
        return right;
    }

    public void setRight(boolean right) {
        this.right = right;
    }

    
    
}
